<?php

namespace App\Http\Controllers;


use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register(Request $request) {

        // data from the input 

        $fields = $request->validate([
            'name' => 'required|string',
            'email' => 'required|string|unique:users,email',
            'password' => 'required|string|confirmed'

        ]);

        // creating a user 

        $user = User::create([
            'name' => $fields['name'], // whatever is passed in
            'email' => $fields['email'],
            'password' => bcrypt($fields['password'])
        ]);

        $token = $user->createToken('myapptoken')->plainTextToken;

        $response = [
            // the user from the database
            'user' => $user,
            'token' => $token
        ];

        // now we want to return a response and pass in our response variable
        return response($response, 201);
    }
    public function login(Request $request) {

        // data from the input 

        $fields = $request->validate([
            //'name' => 'required|string', we only need email and password to login
            'email' => 'required|string',
            'password' => 'required|string'

        ]);

        // check email
        $user = User::where('email', $fields['email']) ->first(); // even tho it's unique and there shouldn't be more than one, we still want to get the first
        
        // if the email matches above, the user will get put in the user variable
        //
        // check password
        // if no user - if theres no email match, that user doesn exist, and check if the password is wrong, whatever the user passes in $fields[password], we wanna match that with the user password in the database
        if(!$user || !Hash::check($fields['password'], $user->password)){
            return response([
                'message' => 'Bad creds.'
            ],401);
        }
        // if both of these conditions above pass, then it's gonna create the token etc
        

        $token = $user->createToken('myapptoken')->plainTextToken;

        $response = [
            // the user from the database
            'user' => $user,
            'token' => $token
        ];

        // now we want to return a response and pass in our response variable
        return response($response, 201);
    }

    public function logout(Request $request) {
        auth()->user()->tokens()->delete();
        return [
            'message' => 'Logged out'
        ];
    }
}
