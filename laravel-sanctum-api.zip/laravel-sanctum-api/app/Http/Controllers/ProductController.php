<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Product::all();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        // we moved this from the route to here, but we don't want to hardcode this, we want to get it from the request
        /*return Product::create([

            // Here we created a new product 
            'name' => 'Product One',
            'slug' => 'product-one',
            'description' => 'This is product one',
            'price' => '99.99'
        ]);
        */
        $request->validate([
            'name' => 'required',
            'slug' => 'required',
            'price' => 'required'
        ]);
        return Product::create($request->all());
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        // find it by it's id, and for that we have to create a route
        return Product::find($id);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $product = Product::find($id); // this will get the product
        $product-> update($request->all()); // update it will all sent through the request
        return $product;  // return 
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        return Product::destroy($id); // returns 1 if it is deleted, 0 if it is not
    }

    /** 
    * Search for a name 
    * 
    * @param str $name
    * @return \Illuminate\Http\Response
    */

    public function search($name) {
        // if they type a part of the product name, we still want to get that back, if it starts with whatever name is, or ends % na kraju
        return Product::where('name', 'like', '%'. $name . '%')->get();
    }

}
