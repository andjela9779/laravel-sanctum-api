<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    // here we add fillable to actually be able to add any fields through the post request inside api.php
    protected $fillable = [
        'name',
        'slug',
        'description',
        'price'
    ];
}
