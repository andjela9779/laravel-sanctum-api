<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
// use App\Models\Product;  // we don't need this in our route anymore after making the controller


/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/


// ******* PUBLIC ROUTES *******
Route::post('/register',[AuthController::class, 'register']);
Route::post('/login',[AuthController::class, 'login']);
Route::get('/products',[ProductController::class, 'index']);
Route::get('/products/{id}',[ProductController::class, 'show']);
//Route::resource('products', ProductController::class); // THIS SHOULD GIVE US ALL OF OUR ROUTES
Route::get('/products/search/{name}', [ProductController::class,'search']);

//    SEARCH ROUTE - if we want to have it protected, we comment it here and copy it in the route::middleware...

//    Route::get('/products/search/{name}', [ProductController::class,'search']);


// ******* PROTECTED ROUTES ******* 
Route::group(['middleware' => ['auth:sanctum']], function() {
    // THIS WILL BE PROTECTED BECAUSE ONLY AUTHENTICATED USERS SHOULD BE ABLE TO ADD NEW PRODUCTS
    // YOU NEED A TOKEN TO BE ABLE TO DO THESE
    Route::post('/products',[ProductController::class, 'store']);
    Route::put('/products/{id}',[ProductController::class, 'update']);
    Route::delete('/products/{id}',[ProductController::class, 'destroy']);
    // logout is also protected because we want to access the logout only if we are authenticated
    Route::post('/logout', [AuthController::class, 'logout']);
});


// we will write this using the controller and the function inside it
//Route::get('/products', function() {
    // we can return all products from our model
    //return Product::all(); we moved this to our controller in the index()
//});
//      Route::get('/products',[ProductController::class, 'index']); - vratili gore

/*Route::post('/products', function() {

    return Product::create([

        // Here we created a new product 
        'name' => 'Product One',
        'slug' => 'product-one',
        'description' => 'This is product one',
        'price' => '99.99'
    ]);

    
    
});
*/ // we will change the one above, with the one above, since we no longer need the function - we moved it into our controller

//      Route::post('/products',[ProductController::class, 'store']);

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
